public class TextCatergorizerMain {
    public static void main(String args[]){
        TextCategorize txtc = new TextCategorize("Hello my name is Isabelle and I like to code");
        txtc.categorize();
        //System.out.println(txtc.getCategories());
        //System.out.println(txtc.getWordCount());
        //System.out.println(txtc.getWordsFor("i"));
    }
}
