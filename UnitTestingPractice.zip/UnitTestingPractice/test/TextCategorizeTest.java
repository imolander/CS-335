import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class TextCategorizeTest {
    private TextCategorize txtc;

    @BeforeEach
    void setUp() {
        txtc = new TextCategorize("Hello my name is Isabelle");
        txtc.categorize();
    }

    @Test
    void categorize() {
        assertTrue(txtc.getCategories() != null);
    }

    @Test
    void getCategories() {
        ArrayList<String> expectedArrayList = new ArrayList<>( Arrays.asList("h", "i",  "m" ,"n"));
        assertEquals(expectedArrayList, txtc.getCategories());
    }

    @Test
    void getWordCount() {
        assertEquals(5, txtc.getWordCount());
    }

    @Test
    void getWordsFor() {
        ArrayList<String> expectedArrayList = new ArrayList<>( Arrays.asList("is", "Isabelle"));
        assertEquals(expectedArrayList, txtc.getWordsFor("i"));
    }
}